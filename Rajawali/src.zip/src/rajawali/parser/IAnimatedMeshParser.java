package rajawali.parser;

import rajawali.animation.mesh.AAnimationObject3D;

public interface IAnimatedMeshParser extends IParser {
	public AAnimationObject3D getParsedAnimationObject();
}
