package rajawali.parser;

import rajawali.BaseObject3D;

public interface IMeshParser extends IParser {
	public BaseObject3D getParsedObject();
}
