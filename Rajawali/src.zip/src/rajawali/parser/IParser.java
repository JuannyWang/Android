package rajawali.parser;

import rajawali.parser.AParser.ParsingException;


public interface IParser {
	public IParser parse() throws ParsingException;
}
