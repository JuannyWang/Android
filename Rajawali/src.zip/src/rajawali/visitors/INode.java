package rajawali.visitors;

public interface INode {
	public void accept(INodeVisitor visitor);
}
