package rajawali.visitors;

public interface INodeVisitor {
	void apply(INode node);
}
