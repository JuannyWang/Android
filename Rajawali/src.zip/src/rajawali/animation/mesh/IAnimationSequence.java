package rajawali.animation.mesh;

public interface IAnimationSequence {

}
