package rajawali.util;

public interface FPSUpdateListener {
	void onFPSUpdate(double fps);
}
