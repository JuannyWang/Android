package rajawali.util;
import rajawali.BaseObject3D;

public interface OnObjectPickedListener {
	public void onObjectPicked(BaseObject3D object);
}
