package com.autograph.data;

public class PointS {
	
	public PointS(int x,int y) {
		this.x=(short) x;
		this.y=(short) y;
	}
	
	public PointS() {
		this(0,0);
	}
	
	public short x;
	public short y;
	
}
