/**
 * 
 */
package com.ghost.interfaces;

/**
 * @author 玄雨
 * @qq 821580467
 * @date 2013-7-10
 */
public interface TestInterface {
	
	public int getCount();

}
